package de.cau.infprogoo.connectfour;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.Thread.State;

public class ReplayController extends Controller {

	private final String path;
	
	private boolean shouldRun = true;

	private Thread replayer = new Thread(new Replayer());

	public ReplayController(Model model, String path) {
		super(model);
		this.path = path;
	}

	public boolean start() {
		if (replayer.isAlive() || replayer.getState() == State.TERMINATED) {
			return false;
		} else {
			shouldRun = true;
			replayer.start();
			return true;
		}
	}
	
	public void reset() {
		shouldRun = false;
		while(replayer.isAlive()) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		inputReceived(Inputs.RESET);
		
		replayer = new Thread(new Replayer());
	}

	private class Replayer implements Runnable {

		@Override
		public void run() {
			try {
				BufferedReader reader = new BufferedReader(new FileReader(path));

				while (shouldRun) {
					String line = reader.readLine();

					if (line == null) {
						reader.close();
						break;
					}
					if (line.equals("LEFT")) {
						inputReceived(Inputs.LEFT);
					} else if (line.equals("RIGHT")) {
						inputReceived(Inputs.RIGHT);
					} else if (line.equals("SELECT")) {
						inputReceived(Inputs.SELECT);
					} else if (line.equals("WIN")) {
						inputReceived(Inputs.WIN);
					} else if (line.equals("RESET")) {
						Thread.sleep(2000);
						inputReceived(Inputs.RESET);
					}
					Thread.sleep(500);
				}

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}
}
