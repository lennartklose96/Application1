package de.cau.infprogoo.connectfour;

import java.awt.Color;

import acm.graphics.*;

public class GuiView extends GCompound implements View {

	private boolean idle = true;
	
	private int height;

	private int width;
	
	private Model lastModel;
	
	public GuiView(int height, int width) {
		this.width = width;
		this.height = height;
	}

	public void setHeight(int height) {
		this.height = height;
		if(lastModel != null)
			update(lastModel);
	}
	
	
	public void setWidth(int width) {
		this.width = width;
		if(lastModel != null)
			update(lastModel);
	}
	
	@Override
	public void update(Model m) {
		idle = false;
		lastModel = m;
		Pieces[][] board = m.getBoard();

		// Clear everything of this compound and redraw everything.
		this.removeAll();

		double componentWidth = Math.min(width, height) / 9.0;
		
		GArrow pointer = new GArrow(componentWidth, componentWidth);
		pointer.setFillColor(m.isRedCurrentPlayer() ? Color.RED : Color.YELLOW);
		pointer.setFilled(true);
		add(pointer, m.getSelect() * componentWidth - componentWidth*4, 0 - componentWidth*4.5);

		for (int x = 0; x < board.length; x++) {
			for (int y = 0; y < board[x].length; y++) {
				GOval dot = new GOval(componentWidth, componentWidth);
				if (board[x][y] == Pieces.RED_PIECE) {
					dot.setFillColor(Color.RED);
					dot.setFilled(true);
				} else if (board[x][y] == Pieces.YELLOW_PIECE) {
					dot.setFillColor(Color.YELLOW);
					dot.setFilled(true);
				}
				add(dot , componentWidth * x - componentWidth*4, componentWidth * (y + 1) - componentWidth*4.5);
			}
		}
				
		if (!m.isGameGoing()) {
			
			remove(pointer);
			String winnerText;
			switch (m.getWinner()) {
			case 1:
				winnerText = "Red won!";
				break;
			case 2:
				winnerText = "Yellow won!";
				break;
			default:
				winnerText = "Tie!";
			}
			
			// Secret win!
			if (m.getSecretWinCon()) {
				
				winnerText = "You won... but at what cost?";
				this.removeAll();
				
				for (int x = 0; x < board.length; x++) {
					for (int y = 0; y < board[x].length; y++) {
						GOval dot = new GOval(componentWidth, componentWidth);
						if (board[x][y] != Pieces.EMPTY) {
							dot.setFillColor(Color.GREEN);
							dot.setFilled(true);
						}
						add(dot, componentWidth * x - componentWidth*4, componentWidth * (y + 1) - componentWidth*4.5);
					}
				}
			}
			
			GLabel winnerLabel = new GLabel(winnerText);
			
			winnerLabel.setFont("SansSerif-25");
			
			winnerLabel.move(0, winnerLabel.getHeight());
			
			add(winnerLabel, 10-componentWidth*4, 40 - componentWidth*4.5);
		}
		idle = true;
	}
	

	@Override
	public boolean isIdle() {
		return idle;
	}

	@Override
	public void close() {

	}

}
