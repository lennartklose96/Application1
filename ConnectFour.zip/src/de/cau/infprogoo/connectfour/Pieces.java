package de.cau.infprogoo.connectfour;

public enum Pieces {
	
	EMPTY,
	RED_PIECE,
	YELLOW_PIECE;

}
