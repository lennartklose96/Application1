package ads.set04.airports;

import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class AirportReducer {
	
	/**
	 * Finds a set of connections that belong to a minimal spanning tree in the
	 * given graph using the algorithm of Jarnik / Prim.
	 * 
	 * @param airports
	 *            a list of airports. Airports have incident connections, and it
	 *            is these connections that shall form the MST returned by this
	 *            method. You can assume that there exists a direct or indirect
	 *            connection between any pair of airports, and that the set
	 *            contains at least one airport.
	 * @return the connections that form a minimal spanning tree.
	 */
	public static Set<Connection> minimalSpanningTree(final List<Airport> airports) {
		
		// Null exception
		if (airports == null) {
			throw new IllegalArgumentException("Null is not a valid argument!");
		}
	    
		// Declaring the Set that is gonna be returned at the end.
		Set<Connection> result = new HashSet<Connection>();
		
		// The current airports in the tree (U).
		Set<Airport> currentSet = new HashSet<Airport>();

		// The currently cheapest price of the Connections available.
		int cheapest;
		Connection cheapestConnection;
		
		
		// Adding the head element.
		currentSet.add(airports.get(0));
		
		// Main Algorithm. Iterates until every airport is in the Set.
		while (currentSet.size() < airports.size()) {
			
			// Resetting the cheapest value and connection.
			// cheapest is set to the Integer limit.
			cheapest = 2147483647;
			cheapestConnection = null;
			
			// Checking the cheapest connection.
			for (Airport current: currentSet) {
				
				Set<Connection> currentConnections = current.getConnections();
				
				// Checking every connection of the current set U.				
				for (Connection connection: currentConnections) {
					
					if (connection.getCost() < cheapest) {
						
						// Checking if the target Airport is part of the set.
						// If not, the cheapest connection updates.
						if (!(currentSet.contains(connection.getAirport1()) && currentSet.contains(connection.getAirport2()))) {
							cheapest = connection.getCost();							
							cheapestConnection = connection;
						}
					}
				}
			}
			
			// Adding the airport of the connection to the set (whichever one it is) and adding the connection.
			// Because a HashSet doesn't allow duplicate entries this works reliably.
			currentSet.add(cheapestConnection.getAirport1());
			currentSet.add(cheapestConnection.getAirport2());
			result.add(cheapestConnection);
		}
		
		return result;
	}

}
