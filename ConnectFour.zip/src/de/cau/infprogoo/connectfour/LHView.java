package de.cau.infprogoo.connectfour;

import java.awt.Color;

import de.cau.infprogoo.lighthouse.ILighthouseInputListener;
import de.cau.infprogoo.lighthouse.LighthouseDisplay;

public class LHView implements View {

	protected static final int BLOCK_WIDTH = 4;

	protected static final int BLOCK_HEIGHT = 2;

	protected static final int LH_HEIGHT = 14;

	protected static final int LH_WIDTH = 28;

	protected static final Color COLOR_LIGHT_RED = new Color(255, 127, 127);

	protected static final Color COLOR_LIGHT_YELLOW = new Color(255, 255, 127);

	private final LighthouseDisplay display;

	protected LighthouseDisplay getDisplay() {
		return display;
	}

	private boolean idle = true;

	private static final String USERNAME = "222821";

	private static final String TOKEN = "API-TOK_XUxq-Hihh-yBWG-wGnC-QK1G";

	public LHView() {
		try {
			display = LighthouseDisplay.getDisplay();
			display.setUsername(USERNAME);
			display.setToken(TOKEN);

			// Wait for Connection to establish
			while (!display.isConnected()) {
				System.out.println("not yet connected");
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			System.out.println("Connection failed: " + e.getMessage());
			e.printStackTrace();
			throw new IllegalAccessError();
		}

	}

	@Override
	public synchronized void update(Model m) {
		idle = false;
		Pieces[][] board = m.getBoard();

		// This array contains for every window (14 rows, 28 columns) three
		// bytes that define the red, green, and blue component of the color
		// to be shown in that window. See documentation of LighthouseDisplay's
		// send(...) method.
		byte[] data = new byte[LH_HEIGHT * LH_WIDTH * 3];

		Color selectColor;
		if (m.isRedCurrentPlayer()) {
			selectColor = COLOR_LIGHT_RED;
		} else {
			selectColor = COLOR_LIGHT_YELLOW;
		}

		addPiece(data, m.getSelect(), 0, selectColor);

		for (int x = 0; x < board.length; x++) {
			for (int y = 0; y < board[x].length; y++) {
				if (m.getSecretWinCon() && board[x][y] != Pieces.EMPTY) {
					addPiece(data, x , BLOCK_HEIGHT * (y + 1), Color.GREEN);
				} else if (board[x][y] == Pieces.RED_PIECE) {
					addPiece(data, x, BLOCK_HEIGHT * (y + 1), Color.RED);
				} else if (board[x][y] == Pieces.YELLOW_PIECE) {
					addPiece(data, x, BLOCK_HEIGHT * (y + 1), Color.YELLOW);
				}
			}
		}

		try {
			display.sendImage(data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		idle = true;

	}

	protected void addPiece(byte[] data, int x, int y, Color c) {
		int startPosition = (LH_WIDTH * y + BLOCK_WIDTH * x) * 3;

		for (int verticalOffset = 0; verticalOffset < BLOCK_HEIGHT; verticalOffset++) {
			for (int horizontalOffset = 0; horizontalOffset < 4; horizontalOffset++) {
				// red component
				int position = startPosition + (3 * horizontalOffset) + (3 * LH_WIDTH * verticalOffset);
				data[position + 0] = (byte) c.getRed();
				// green component
				data[position + 1] = (byte) c.getGreen();
				// blue component
				data[position + 2] = (byte) c.getBlue();
			}
		}
	}

	public void addButtonListener(ILighthouseInputListener listener) {
		try {
			display.enableKeyInputs();
		} catch (Exception e) {
		}

		display.addButtonListener(listener);
	}

	@Override
	public boolean isIdle() {
		return idle;
	}

	@Override
	public void close() {
		display.close();
	}

}
