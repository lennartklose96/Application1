package de.cau.infprogoo.connectfour.test;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;

import acm.program.GraphicsProgram;
import de.cau.infprogoo.connectfour.GuiView;
import de.cau.infprogoo.connectfour.LHView;
import de.cau.infprogoo.connectfour.Model;
import de.cau.infprogoo.connectfour.ReplayController;

public class ReplayTest extends GraphicsProgram {

	private Model m = new Model();

	private GuiView view;

	private ReplayController replay = new ReplayController(m, "/tmp/replay.txt");

	@Override
	public void init() {
		addKeyListeners();

		view = new GuiView(getHeight(), getWidth());

		add(view, getWidth() / 2.0, getHeight() / 2);
		m.addView(view);
		LHView lhView = new LHView();
		m.addView(lhView);

		add(new JButton("Reset"), SOUTH);
		add(new JButton("Start"), SOUTH);

		addActionListeners();
		
		addWindowListener(new CloseHelper());

		// The Lighthouse-API seems to time-out if no update is send for some time.
		// This dirty solution fixes this problem.
		new Thread(() -> {
			while (true) {
				lhView.update(m);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		replay.start();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Reset"))
			replay.reset();
		else if (e.getActionCommand().equals("Start"))
			replay.start();
	}

	public static void main(String[] args) {
		new ReplayTest().start();
	}

	private class CloseHelper extends WindowAdapter {

		@Override
		public void windowClosing(WindowEvent e) {
			m.closeViews();
			System.exit(0);
		}

	}

}
