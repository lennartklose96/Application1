package de.cau.infprogoo.connectfour;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionController extends Controller implements ActionListener {

	public ActionController(Model model) {
		super(model);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println(e.getActionCommand());
		
		if (e.getActionCommand().equals("Reset")) {
			inputReceived(Inputs.RESET);
		}

	}

}
