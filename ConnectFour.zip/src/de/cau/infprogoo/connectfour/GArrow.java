package de.cau.infprogoo.connectfour;

import acm.graphics.GPolygon;

public class GArrow extends GPolygon {
	
	public GArrow(double width, double height) {
		addVertex(width / 3.0, 0.0);
		addVertex(2 * width / 3.0, 0.0);
		addVertex(2 * width / 3.0, height / 2.0);
		addVertex(width , height / 2.0);
		addVertex(width / 2.0, height);
		addVertex(0, height / 2.0);
		addVertex(0, height / 2.0);
		addVertex(width / 3.0, height / 2.0);
	}

}
