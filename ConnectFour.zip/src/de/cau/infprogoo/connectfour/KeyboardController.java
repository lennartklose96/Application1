package de.cau.infprogoo.connectfour;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyboardController extends Controller implements KeyListener {

	public KeyboardController(Model model) {
		super(model);
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		switch (e.getKeyCode()) {
		case KeyEvent.VK_LEFT:
		case KeyEvent.VK_A:
			// move select left
			inputReceived(Inputs.LEFT);
			break;
		case KeyEvent.VK_RIGHT:
		case KeyEvent.VK_D:
			inputReceived(Inputs.RIGHT);
			break;
		case KeyEvent.VK_SPACE:
		case KeyEvent.VK_ENTER:
			inputReceived(Inputs.SELECT);
			break;
		case KeyEvent.VK_4:
		case KeyEvent.VK_NUMPAD4:
			inputReceived(Inputs.WIN);
			break;
		case KeyEvent.VK_R:
			inputReceived(Inputs.RESET);
			break;
		case KeyEvent.VK_ESCAPE:
			// close Program
			inputReceived(Inputs.EXIT);
			System.exit(0);
		}
		

	}

	@Override
	public void keyReleased(KeyEvent e) {
	}

}
