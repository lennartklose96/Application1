package de.cau.infprogoo.connectfour.test;

import de.cau.infprogoo.lighthouse.*;

import java.io.IOException;

public class Test {

    public static void main(String[] args) {
        LighthouseDisplay d = null;
        try {
            d = LighthouseDisplay.getDisplay();
            d.setUsername("stu221128");
            d.setToken("API-TOK_UM50-+O3x-jTBS-ufi+-KnxK");

            // This is really important!
            // Waiting for the connection to be established
            while (!d.isConnected()) {
                System.out.println("not yet connected");
                Thread.sleep(2000);
            }
            try {
            	for (int x = 1; x < 200; x++) {
            		// This array contains for every window (14 rows, 28 columns) three
            		// bytes that define the red, green, and blue component of the color
            		// to be shown in that window. See documentation of LighthouseDisplay's
            		// send(...) method.
            		byte[] data = new byte[14 * 28 * 3];
            		
            		for (int i = 0; i < data.length / 3; i++) {
            			switch ((i + x) % 13) {
            			case 0:
            				if (i / 28 % 3 == 0) {
            					// RED component
            					data[i * 3] = (byte) 0;
            					// GREEN component
            					data[i * 3 + 1] = -50;
            					// BLUE component
            					data[i * 3 + 2] = -1;
            				} else {
            					// RED component
            					data[i * 3] = (byte) 0;
            					// GREEN component
            					data[i * 3 + 1] = 50;
            					// BLUE component
            					data[i * 3 + 2] = 1;
            				}
            				break;
            			case 1:
            				// RED component
            				data[i * 3] = -1;
            				// GREEN component
            				data[i * 3 + 1] = 127;
            				// BLUE component
            				data[i * 3 + 2] = 0;
            				break;
            			case 2:
            				// RED component
            				data[i * 3] = 0;
            				// GREEN component
            				data[i * 3 + 1] = 127;
            				// BLUE component
            				data[i * 3 + 2] = 0;
            				break;
            			case 3:
            				// RED component
            				data[i * 3] = 0;
            				// GREEN component
            				data[i * 3 + 1] = 127;
            				// BLUE component
            				data[i * 3 + 2] = -1;
            				break;
            			case 4:
            				// RED component
            				data[i * 3] = 0x33;
            				// GREEN component
            				data[i * 3 + 1] = 0x33;
            				// BLUE component
            				data[i * 3 + 2] = 0x33;
            				break;
            			default:
            				// RED component
            				data[i * 3] = (byte) 0xAF;
            				// GREEN component
            				data[i * 3 + 1] = (byte) 0xF0;
            				// BLUE component
            				data[i * 3 + 2] = (byte) 0x34;
            			}
            		}
            		
            		d.sendImage(data);
            		Thread.sleep(250);
            	}
            } catch (IOException | InterruptedException e) {
            	System.out.println("Connection failed: " + e.getMessage());
            	e.printStackTrace();
            } finally {
            	d.close();
            }
        } catch (Exception e) {
            System.out.println("Connection failed: " + e.getMessage());
            e.printStackTrace();
        }

    }
}
