package de.cau.infprogoo.connectfour;

import de.cau.infprogoo.lighthouse.ILighthouseInputListener;

public class LHController extends Controller implements ILighthouseInputListener {

	public LHController(Model model) {
		super(model);
	}

	@Override
	public void keyboardEvent(int source, int button, boolean down) {
		System.out.println("[KEYBOARD] source: " + source + " button: " + button + " down: " + down);

		if (down) {
			switch (button) {
			case 37:
			case 65:
				// move select left
				inputReceived(Inputs.LEFT);
				break;
			case 39:
			case 68:
				inputReceived(Inputs.RIGHT);
				break;
			case 13:
			case 32:
				inputReceived(Inputs.SELECT);
				break;
			case 52:
				inputReceived(Inputs.WIN);
				break;
			case 100:
				inputReceived(Inputs.WIN);
				break;
			case 82:
				inputReceived(Inputs.RESET);
				break;
			case 27:
				// close Program
				inputReceived(Inputs.EXIT);
				System.exit(0);
			}
		}

	}

	@Override
	public void controllerEvent(int source, int button, boolean down) {
		System.out.println("[CONTROLLER] source: " + source + " button: " + button + " down: " + down);

		if (down) {
			switch (button) {
			case 4:
			case 6:
			case 14:
			case 17:
				// move select left
				inputReceived(Inputs.LEFT);
				break;
			case 5:
			case 7:
			case 15:
			case 20:
				inputReceived(Inputs.RIGHT);
				break;
			case 0:
			case 1:
				inputReceived(Inputs.SELECT);
				break;
			case 8:
			case 9:
				// close Program
				inputReceived(Inputs.EXIT);
				System.exit(0);
			}
		}
	}

}
