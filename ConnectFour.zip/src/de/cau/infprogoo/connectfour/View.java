package de.cau.infprogoo.connectfour;

public interface View {
	
	/**
	 * Updates the View according to the state of the provided model.
	 * @param m The Model on which to update.
	 */
	void update(Model m);
	
	/**
	 * Test if the View is ready to receive an update.
	 * @return if the View is ready.
	 */
	boolean isIdle();
	
	/**
	 * Closes the View.
	 */
	void close();

}
