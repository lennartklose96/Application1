package de.cau.infprogoo.connectfour;

import java.awt.Color;

public class LHViewAnim extends LHView {

	private byte[] data = new byte[LH_HEIGHT * LH_WIDTH * 3];

	private boolean[][] used = new boolean[7][7];

	private Thread t;

	@Override
	public synchronized void update(Model m) {

		if (m.isEmpty()) {
			data = new byte[LH_HEIGHT * LH_WIDTH * 3];
			used = new boolean[7][7];
		} else {

			Pieces[][] board = m.getBoard();

			// This array contains for every window (14 rows, 28 columns) three
			// bytes that define the red, green, and blue component of the color
			// to be shown in that window. See documentation of LighthouseDisplay's
			// send(...) method.

			Color selectColor;
			if (m.isRedCurrentPlayer()) {
				selectColor = COLOR_LIGHT_RED;
			} else {
				selectColor = COLOR_LIGHT_YELLOW;
			}

			for (int i = 0; i < 7; i++) {
				addPiece(data, i, 0, Color.BLACK);
			}

			addPiece(data, m.getSelect(), 0, selectColor);

			for (int x = 0; x < board.length; x++) {
				for (int y = 0; y < board[x].length; y++) {
					if (m.getSecretWinCon() && board[x][y] != Pieces.EMPTY) {
						addPiece(data, x, y + 1, Color.GREEN);
					} else if (!used[x][y + 1] && board[x][y] != Pieces.EMPTY) {
						used[x][y + 1] = true;
						t = new Thread(new PieceDropper(x, y + 1, board[x][y], m));
						t.start();
					}
				}
			}
		}
		try {
			getDisplay().sendImage(data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public boolean isIdle() {
		if (t == null)
			return true;
		else
			return !t.isAlive();
	}

	private class PieceDropper implements Runnable {

		private final int x;
		private final int y;
		private final Pieces p;
		private final Model m;

		public PieceDropper(int x, int y, Pieces p, Model m) {
			this.x = x;
			this.y = y;
			this.p = p;
			this.m = m;
		}

		@Override
		public void run() {

			Color pieceColor = p == Pieces.RED_PIECE ? Color.RED : Color.YELLOW;
			for (int i = 1; i <= 2 * y; i++) {
				addPiece(data, x, i, pieceColor);

				try {
					getDisplay().sendImage(data);
					Thread.sleep(100);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (i > 1)
					addPiece(data, x, i, Color.BLACK);
			}

			addPiece(data, x, 2 * y, pieceColor);
			update(m);
		}
	}
}
