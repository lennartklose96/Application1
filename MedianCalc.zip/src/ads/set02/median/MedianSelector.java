package ads.set02.median;

public class MedianSelector {

	/**
	 * Computes and retrieves the lower median of the given array of pairwise
	 * distinct numbers using the Median algorithm presented in the lecture.
	 * 
	 * @param numbers array with pairwise distinct numbers.
	 * @return the lower median.
	 * @throw IllegalArgumentException if the array is {@code null} or empty.
	 */
	public static int lowerMedian(int[] numbers) {
		

		// Null exception
		if (numbers == null) {
			throw new IllegalArgumentException("Array can't be null!");
		}

		// Empty array exception
		if (numbers.length == 0) {
			throw new IllegalArgumentException("Array can't be empty!");
		}
		
		// Integer for the array length.
		int n = numbers.length;

		// Integer for the position
		int position = (n + 1) / 2;
		
		// Main method to calculate the median at position;
		return findMedian(numbers, position);

	}
	
	/** 
	 * The main method used to find the median using the Median algorithm
	 * presented in the lecture.
	 * 
	 * @param numbers the array to find the median in.
	 * @param position the position in the array the median will be found at (Index + 1).
	 * @return the lower Median.
	 */
	public static int findMedian(int[] numbers, int position) {

		// Length of array
		int n = numbers.length;

		// Returning the first element of the array if it is the only element present
		if (n == 1) {
			return numbers[0];
		}

		// Returning the median.
		if (n <= 5) {
			quicksort(numbers, 0, numbers.length-1);
			// Returning position - 1, because the position starts counting at 1, 
			// whereas the index of an array starts counting at 0.
			return numbers[position - 1];
		}

		// Initializing lots of variables
		int partition = n / 5;
		int rest = n % 5;

		// Initializing the arrays for the new smaller arrays and the array of medians.
		int newNumbers[][] = new int[partition][5];
		int newRest[] = null;
		int medians[] = null;

		// Setting the size for the rest and medians array.
		if (rest > 0) {
			newRest = new int[rest];
			medians = new int[partition + 1];
		} else {
			medians = new int[partition];
		}

		// Counter to cycle through the initial array.
		int counter = 0;

		// Filling the n / 5 arrays.
		for (int i = 0; i < partition; i++) {
			for (int j = 0; j < 5; j++) {
				newNumbers[i][j] = numbers[counter];
				counter++;
			}
			// Finds the medians of the smaller arrays.
			quicksort(newNumbers[i], 0, newNumbers[i].length-1);
			medians[i] = newNumbers[i][2];
		}

		// Filling the n % 5 array (if present).
		if (rest > 0) {
			for (int i = 0; i < rest; i++) {
				newRest[i] = numbers[counter];
				counter++;
			}
			// Finding the median of the n % 5 array.
			quicksort(newRest, 0, newRest.length-1);
			medians[partition] = newRest[newRest.length/2];
		}

		// Finding the median of medians.
		quicksort(medians, 0, medians.length-1);
		int medianPosition = (medians.length + 1) / 2;
		int median = findMedian(medians, medianPosition);

		// Defining the arrays of lower and upper numbers,
		// as well as counters for the amount of numbers in each array.
		int[] lowerNumbers, upperNumbers;
		int lowerCount = 0;
		int upperCount = 0;

		for (int i = 0; i < n; i++) {
			if (numbers[i] < median) {
				lowerCount++;
			}
			if (numbers[i] > median) {
				upperCount++;
			}
		}

		// Initializing and filling the two new arrays.
		lowerNumbers = new int[lowerCount];
		upperNumbers = new int[upperCount];
		int lowerIndex = 0;
		int upperIndex = 0;

		for (int i = 0; i < n; i++) {
			if (numbers[i] < median) {
				lowerNumbers[lowerIndex] = numbers[i];
				lowerIndex++;
			}
			if (numbers[i] > median) {
				upperNumbers[upperIndex] = numbers[i];
				upperIndex++;
			}
		}

		// TODO: Find stuff in new arrays!
		int k = lowerCount + 1;

		if (position == k) {
			return median;
		}

		// Finding the new median at the new position.

		if (position < k) {
			return findMedian(lowerNumbers, position);
		} else {
			return findMedian(upperNumbers, position-k);			
		}
	}
	
	/**
	 * Sorts an array with quicksort method
	 * 
	 * @param numbers
	 */
	private static void quicksort(int[] numbers, int left, int right) {
		
		// Defining variables needed to calculate.
		int x, i, j, temp;
		if (left < right) {
			x = numbers[left]; i = left+1; j = right;
			while (i <= j) {
				
				while (i <= j && numbers[i] <=x) {
					i++;
				}
				
				while (i <= j && numbers[j] >=x){
					j--;
				}
				
				// Swapping elements.				
				if (i < j) {
					temp = numbers[i];
					numbers[i] = numbers[j];
					numbers[j] = temp;
				}
			}
			
			i--;
			numbers[left] = numbers[i];
			numbers[i] = x;
			quicksort(numbers, left, i-1);
			quicksort(numbers, i+1, right);
		}
	}
	
	public static void main(String[] args) {
		
		/////////////////////////////////
		// PERSONAL TESTING BEST IGNORED	
		/////////////////////////////////
		
		int[] test = {2060, 2065, 2033, 1983, 1994, 2010, 2027, 2001, 2042, 2067, 2064, 2051, 2017, 2018, 2074, 1997, 2014, 1999, 2034, 2083, 2038, 2084, 1989, 2081, 2023};
		System.out.println("Median using Algorithm: " +lowerMedian(test));
		
		quicksort(test, 0, test.length-1);
		
		for (int i = 0; i < test.length; i++) {
			System.out.println(test[i]);
		}
		
		System.out.println("Median found in sorted Array: " + test[test.length/2]);
		
	}

}
