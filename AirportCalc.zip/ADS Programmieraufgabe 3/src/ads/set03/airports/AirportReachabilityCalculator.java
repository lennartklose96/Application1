package ads.set03.airports;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class AirportReachabilityCalculator {
	
	/**
	 * Finds airports that are directly or indirectly reachable from all other
	 * airports. Phrase differently: for each airport {@code a} in the result it
	 * must hold that there is a directed path from each other airport {@code b} to
	 * {@code a}.
	 * 
	 * @param airports the set of airports.
	 * @return the set of always reachable airports.
	 * @throws IllegalArgumentException if {@code airports} is {@code null}.
	 */
	public static Set<Airport> findAlwaysReachableAirports(Set<Airport> airports) {
		
		// null exception
		if (airports == null) {
			throw new IllegalArgumentException("airports can't be null!");
		}
		
		// How many airports are in the set.
		int amount = numberOfAirports(airports);
		
		// This HashMap will store if a certain airport has been visited already.
		HashMap<Airport, Boolean> visitedAirports = new HashMap<Airport, Boolean>();
		
		// This HashMap will count how often each airport has been visited.		
		HashMap<Airport, Integer> amountVisited = new HashMap<Airport, Integer>();
		
		// Filling the HashMaps.		
		for (Airport airport: airports) {
			visitedAirports.put(airport, false);
			amountVisited.put(airport, 0);
		}
		
		// Updating the @amountVisited HashMap to find out how often each airport can be visited.				
		for (Airport airport: airports) {
			
			findDestinations(airport, visitedAirports, amountVisited);
			
			// Resetting the visited status for each airport.		
			for (Airport element: airports) {
				visitedAirports.replace(element, false);
			}
		}
		
		// The set of airports that can be visited by all the other ones.		
		Set<Airport> result = new HashSet<Airport>();
		
		
		// Adding the airports that can be visited by all others to the result set.
		for (Airport airport: airports) {
			
			if (amountVisited.get(airport) == amount) {
				result.add(airport);
			}
			
		}
		
		return result;
		
	}
	
	/**
	 * This method recursively checks for the given airport and it's destinations, which airports are reachable from 
	 * the starting airport {@code airport}. It updates if an airport has been visited via the {@code mapVisited} HashMap,
	 * and updates the information of how often each airport has been visited in total with the {@code mapAmount} HashMap.
	 * 
	 * @param airport the airport to check.
	 * @param mapVisited the HashMap that shows if an airport has been previously visited.
	 * @param mapAmount the HashMap that shows how often an airport has already been visited.
	 */
	
	private static void findDestinations(Airport airport, HashMap<Airport, Boolean> mapVisited, HashMap<Airport, Integer> mapAmount) {	
		
		// Updates the Map to indicate this airport has been visited.		
		mapVisited.replace(airport, true);
		
		// Updating the amount of time this airport has been visited.
		int temp = mapAmount.get(airport);
		mapAmount.replace(airport, temp + 1);
		
		// Set of all the current destinations for @airport.
		Set<Airport> currentDestinations = airport.getDestinations();
		
		// Checking for every destination of the airport recursively if it is reachable. If it has been previously reached, it won't "fly" there again.
		for (Airport destination: currentDestinations) {
			
			// Checking if the airport has been visited.
			if (!mapVisited.get(destination)) {
				findDestinations(destination, mapVisited, mapAmount);
			}
		}
		
	}
	
	/**	
	 * Counting how many airports are in a set of airports
	 * 
	 * @param airports the set to count in.
	 * @return the amount of airports in the set.
	 * @throws IllegalArgumentException if {@code airports} is {@code null}.
	 */
	private static int numberOfAirports(Set<Airport> airports) {
		
		if (airports == null) {
			throw new IllegalArgumentException("airports can't be null!");
		}
		
		// Counter for the amount of elements in the set.
		int amount = 0;	
				
		// Counts how many elements are in the Set.
		for (Airport element: airports) {
			amount++;		
		}
		
		return amount;
	}
}
