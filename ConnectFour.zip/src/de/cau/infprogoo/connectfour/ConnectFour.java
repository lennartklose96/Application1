package de.cau.infprogoo.connectfour;

import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.JButton;

import acm.program.GraphicsProgram;

public class ConnectFour extends GraphicsProgram implements ComponentListener {
	
	// The model of the ConnectFour game.
	private Model m = new Model();

	// GUI view.
	private GuiView view;

	@Override
	public void init() {
		
		addComponentListener(this);
		
		KeyboardController keyboardController = new KeyboardController(m);
		try {
			keyboardController.enableLogging("/tmp/replay.txt");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		view = new GuiView(getHeight(), getWidth());
		
		add(new JButton("Reset"), SOUTH);
			
		addKeyListeners(keyboardController);
		add(view, 10, 10);
		m.addView(view);
		LHView lhView = new LHView();
		m.addView(lhView);
		
		lhView.addButtonListener(new LHController(m));
		
		// Ensure views are closed when the window is closed.
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		addWindowListener(new CloseHelper());
		
		addActionListeners(new ActionController(m));
		
		// The Lighthouse-API seems to time-out if no update is send for some time.
		// This dirty solution fixes this problem.
//		new Thread(() -> {
//			while (true) {
//				lhView.update(m);
//				try {
//					Thread.sleep(1000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		}).start();

	}

	public static void main(String[] args) {
		new ConnectFour().start();
	}
	
	

	private class CloseHelper extends WindowAdapter {
		
		@Override
		public void windowClosing(WindowEvent e) {
			m.closeViews();
			System.exit(0);
		}
		
	}
	
	@Override
	public void componentResized(ComponentEvent e) {
		view.setHeight(getHeight());
		view.setWidth(getWidth());
		// Scaling the view.
		add(view, getWidth() / 2, getHeight() / 2);}

	@Override
	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentShown(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentHidden(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
