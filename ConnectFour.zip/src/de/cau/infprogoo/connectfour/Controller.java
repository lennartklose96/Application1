package de.cau.infprogoo.connectfour;

import java.io.IOException;
import java.io.PrintWriter;

public abstract class Controller {

	private static final int BOARD_WIDTH = 6;

	// The model the controller controls.
	private final Model model;

	private PrintWriter logger = null;

	public Controller(Model model) {
		this.model = model;
	}

	protected void inputReceived(Inputs input) {
		
		if(model.viewsReady()) {
			
			// The select.
			int select = model.getSelect();
			// Who won the game.
			int victor = 0;
			
			// Checking if the game is still going on.
			if (model.isGameGoing()) {
				switch (input) {
				
				// Moves the piece left.
				case LEFT:
					model.setSelect(select <= 0 ?
							BOARD_WIDTH :
								select - 1);
					break;
					
					// Moves the piece right.
				case RIGHT:
					model.setSelect(select >= BOARD_WIDTH ?
							0 :
								select + 1);
					break;
					
					// Adds the current players piece into the selected column.
				case SELECT:
					if (model.addPiece(select, model.isRedCurrentPlayer() ? Pieces.RED_PIECE : Pieces.YELLOW_PIECE)) {
						model.setRedCurrentPlayer(!model.isRedCurrentPlayer());
					}
					
					// Checking if there is a winner and ending the game is there is.
					victor = model.getWinner();
					if (victor != 0) {
						model.setGameGoing(false);
						System.out.println("Player " + victor + " won!");
					} else if (model.isFull()) {
						model.setGameGoing(false);
						System.out.println("Tie!");
					}
					break;
					
				case WIN:
					model.setSecretWinCon(true);
					model.setGameGoing(false);
					break;
					
				case EXIT:
					model.closeViews();
					if (logger != null) {
						logger.close();
					}
					
					// Starts a new game.
				case RESET:
					model.setSecretWinCon(false);
					model.setGameGoing(true);
					model.clearBoard();
					model.setRedCurrentPlayer(true);
					model.setSelect(0);
					break;
				}
				
				// Closes the program.
			} else if (input == Inputs.EXIT) {
				model.closeViews();
				// Starts a new game.
			} else if (input == Inputs.RESET) {
				model.setSecretWinCon(false);
				model.setGameGoing(true);
				model.clearBoard();
				model.setRedCurrentPlayer(true);
				model.setSelect(0);
			}
			
			if (logger != null) {
				logger.println(input.name());
				logger.flush();
			}
		}

	}

	public void enableLogging(String path) throws IOException {
		logger = new PrintWriter(path);
	}
}
