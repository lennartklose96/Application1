package de.cau.infprogoo.connectfour;

import java.util.ArrayList;

public class Model {

/////////////////////////////////////////////////////////////////////////////////////
// Fields
/////////////////////////////////////////////////////////////////////////////////////

	/** The List containing every View. */
	private ArrayList<View> views = new ArrayList<>(2);

	// The representation of the board.
	// Index [0][0] is the top left corner of the board.
	private Pieces[][] board = new Pieces[7][6];

	// The row at which the current player is deciding to place their piece.
	private int select;

	// Shows if the game is currently still being played.
	private boolean gameGoing = true;

	private boolean redCurrentPlayer = true;

	public boolean isRedCurrentPlayer() {
		return redCurrentPlayer;
	}
	
	// It's secret to everybody.
	private boolean secretWinCon = false;

/////////////////////////////////////////////////////////////////////////////////////
// Constructor
/////////////////////////////////////////////////////////////////////////////////////

	// Constructor: Initializes an empty board.
	public Model() {

		// Fills the array with empty pieces.
		for (Pieces[] piece : board) {
			for (int i = 0; i < piece.length; i++) {
				piece[i] = Pieces.EMPTY;
			}
		}
	}

/////////////////////////////////////////////////////////////////////////////////////
// Getters and Setters
/////////////////////////////////////////////////////////////////////////////////////
	
	public boolean getRedCurrentPlayer() {
		return redCurrentPlayer;
	}

	public void setRedCurrentPlayer(boolean redCurrentPlayer) {
		this.redCurrentPlayer = redCurrentPlayer;
		//refreshViews();
	}

	public boolean isGameGoing() {
		return gameGoing;
	}

	public void setGameGoing(boolean gameGoing) {
		this.gameGoing = gameGoing;
		refreshViews();
	}

	// Getter for select.
	public int getSelect() {
		return select;
	}

	// Setter for select.
	public void setSelect(int select) {
		this.select = select;
		refreshViews();
	}

	// Getter for the board.
	public Pieces[][] getBoard() {
		return board;
	}
	
	public boolean getSecretWinCon() {
		return secretWinCon;
	}
	
	public void setSecretWinCon(boolean secretWinCon) {
		this.secretWinCon = secretWinCon;
	}

/////////////////////////////////////////////////////////////////////////////////////
// Methods related to the state of the Game
/////////////////////////////////////////////////////////////////////////////////////

	// Adds a piece to the specified row. If a piece was added this method returns
	// true.
	public boolean addPiece(int row, Pieces piece) {

		// There are only 7 rows.
		if (row > 6) {
			throw new IllegalArgumentException("Row can't be greater than 7!");
		}

		// Checks if the row is full.
		if (getFill(row) == 6) {
			return false;
		}

		// The column in which the piece gets added.
		int column = 5 - getFill(row);

		// Adding the piece.
		board[row][column] = piece;
		refreshViews();
		return true;
	}

	// Returns how many pieces are in a given row.
	public int getFill(int row) {

		// Counts how full the specified row is.
		int counter = 0;

		// The row to check.
		Pieces[] current = board[row];

		for (int i = 5; i >= 0; i--) {

			if (current[i] != Pieces.EMPTY) {
				counter++;
			} else {
				return counter;
			}
		}

		return counter;
	}

	// Returns true if the board is filled with pieces.
	public boolean isFull() {

		// Checking the entire board.
		for (Pieces[] piece : board) {
			for (Pieces current : piece) {

				// Returns false if a single piece in the board is empty.
				if (current == Pieces.EMPTY) {
					return false;
				}
			}
		}

		// Returns true if no empty piece was found.
		return true;
	}
	
	// Returns true if the board is empty.
	public boolean isEmpty() {
		boolean flag = true;
		
		for (Pieces[] piece : board) {
			for (Pieces current : piece) {
				if (current != Pieces.EMPTY) {
					flag = false;
				}
			}
		}
		return flag;
	}

	// Resets the board by making all pieces empty.
	public void clearBoard() {

		// Fills the array with empty pieces.
		for (Pieces[] piece : board) {
			for (int i = 0; i < piece.length; i++) {
				piece[i] = Pieces.EMPTY;
			}
		}
	}

	/**
	 * Returns who won the game.
	 * 
	 * @return 0 - if there is no winner 1 - if RED_PIECE won 2 - if YELLOW_PIECE
	 *         won.
	 */
	public int getWinner() {

		int victor = getHorizonalWinner();

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor can only be 1 or 2";
			return victor;
		}

		victor = getVerticalWinner();

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor can only be 1 or 2";
			return victor;
		}

		victor = getDiagonalWinner();

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor can only be 1 or 2";
			return victor;
		}

		// Returns 0 if no winner was found.
		return 0;
	}

	// Checks if any four pieces of the same color are aligned vertically.
	// Returns 0 if no winner as found, 1 if the RED_PIECE won, 2 if the
	// YELLOW_PIECE won.
	private int getVerticalWinner() {

		// Initializing the counter for how many red and yellow pieces are aligned.
		int redCounter = 0;
		int yellowCounter = 0;

		for (Pieces[] row : board) {

			for (Pieces column : row) {

				if (column == Pieces.EMPTY) {
					redCounter = 0;
					yellowCounter = 0;
				}

				if (column == Pieces.RED_PIECE) {
					redCounter++;
					yellowCounter = 0;
				}

				if (column == Pieces.YELLOW_PIECE) {
					yellowCounter++;
					redCounter = 0;
				}

				// Return 1 if there are 4 red pieces aligned vertically.
				if (redCounter == 4) {
					return 1;
				} else {

					// Return 2 if there are 4 yellow pieces aligned vertically.
					if (yellowCounter == 4) {
						return 2;
					}
				}
			}

			// Resets the counter each new column.
			redCounter = 0;
			yellowCounter = 0;
		}

		// Returns 0 if no winner was found.
		return 0;
	}

	// Checks if any four pieces of the same color are aligned horizontally.
	// Returns 0 if no winner as found, 1 if the RED_PIECE won, 2 if the
	// YELLOW_PIECE won.
	private int getHorizonalWinner() {

		// Initializing the counter for how many red and yellow pieces are aligned.
		int redCounter = 0;
		int yellowCounter = 0;

		for (int i = 5; i >= 0; i--) {

			for (Pieces[] row : board) {

				if (row[i] == Pieces.EMPTY) {
					redCounter = 0;
					yellowCounter = 0;
				}

				if (row[i] == Pieces.RED_PIECE) {
					redCounter++;
					yellowCounter = 0;
				}

				if (row[i] == Pieces.YELLOW_PIECE) {
					redCounter = 0;
					yellowCounter++;
				}

				// Return 1 if there are 4 red pieces aligned vertically.
				if (redCounter == 4) {
					return 1;
				} else {

					// Return 2 if there are 4 yellow pieces aligned vertically.
					if (yellowCounter == 4) {
						return 2;
					}
				}
			}

			// Resets the counter each new row.
			redCounter = 0;
			yellowCounter = 0;
		}

		// Returns 0 if no winner was found.
		return 0;
	}

	// Checks if any four pieces of the same color are aligned diagonally.
	// Returns 0 if no winner as found, 1 if the RED_PIECE won, 2 if the
	// YELLOW_PIECE won.
	private int getDiagonalWinner() {

		// Initializing the winner with 0.
		int victor = 0;

		// Checking every diagonal win condition.
		victor = leftCheck(3, 0);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = leftCheck(4, 0);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = leftCheck(5, 0);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = leftCheck(6, 0);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = leftCheck(6, 1);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = leftCheck(6, 2);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = rightCheck(0, 2);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = rightCheck(0, 1);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = rightCheck(0, 0);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = rightCheck(1, 0);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = rightCheck(2, 0);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		victor = rightCheck(3, 0);

		if (victor != 0) {
			assert victor == 1 || victor == 2 : "victor has to be 1 or 2";
			return victor;
		}

		// Returns 0 if no winner was found.
		return 0;
	}

	// One of the diagonal checks.
	private int leftCheck(int rowInput, int columnInput) {

		// Initializing the counter for how many red and yellow pieces are aligned.
		int redCounter = 0;
		int yellowCounter = 0;

		int row = rowInput;
		int column = columnInput;

		Pieces current = board[row][column];

		while (row >= 0 && column < 6) {

			// Updating the current piece.
			current = board[row][column];

			if (current == Pieces.EMPTY) {
				redCounter = 0;
				yellowCounter = 0;
			}

			if (current == Pieces.RED_PIECE) {
				redCounter++;
				yellowCounter = 0;
			}

			if (current == Pieces.YELLOW_PIECE) {
				redCounter = 0;
				yellowCounter++;
			}

			// Player 1 won.
			if (redCounter == 4) {
				return 1;
			}

			// Player 2 won.
			if (yellowCounter == 4) {
				return 2;
			}

			// Jumping diagonally left upwards.
			row--;
			column++;
		}

		// Return 0 if no winner was found.
		return 0;
	}

	// One of the diagonal checks.
	private int rightCheck(int rowInput, int columnInput) {

		// Initializing the counter for how many red and yellow pieces are aligned.
		int redCounter = 0;
		int yellowCounter = 0;

		int row = rowInput;
		int column = columnInput;

		Pieces current = board[row][column];

		while (row < 7 && column < 6) {

			// Updating the current piece.
			current = board[row][column];

			if (current == Pieces.EMPTY) {
				redCounter = 0;
				yellowCounter = 0;
			}

			if (current == Pieces.RED_PIECE) {
				redCounter++;
				yellowCounter = 0;
			}

			if (current == Pieces.YELLOW_PIECE) {
				redCounter = 0;
				yellowCounter++;
			}

			// Player 1 won.
			if (redCounter == 4) {
				return 1;
			}

			// Player 2 won.
			if (yellowCounter == 4) {
				return 2;
			}

			// Jumping diagonally right upwards.
			row++;
			column++;
		}

		// Return 0 if no winner was found.
		return 0;
	}

/////////////////////////////////////////////////////////////////////////////////////
// Methods related to views
/////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Adds a view to this Model.
	 * 
	 * @param view The view to add.
	 */
	public void addView(View view) {
		views.add(view);
		view.update(this);
	}

	/**
	 * Notifies every connected view to refresh itself.
	 */
	private void refreshViews() {
		for (View view : views) {
			if (view.isIdle()) {
				view.update(this);
			}
		}
	}

	/**
	 * Closes every connected view.
	 */
	public void closeViews() {
		for (View view : views) {
			while (!view.isIdle()) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			view.close();
		}
	}
	
	public boolean viewsReady() {
		for (View view : views) {
			if(!view.isIdle()) {
				return false;
			}
		}
		return true;
	}

}
