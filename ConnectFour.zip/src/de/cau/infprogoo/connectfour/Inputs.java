package de.cau.infprogoo.connectfour;

public enum Inputs {
	LEFT,
	RIGHT,
	SELECT,
	WIN,
	EXIT, 
	RESET;
}
